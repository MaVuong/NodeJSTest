function CCShape(w,h){
	this.w=w;
	this.h=h;
}
module.exports=CCShape;