
function getMapAround(location){
	var cx=location%10;
	var cy=Math.floor(location/10);

	var arrayGet=[];
	arrayGet.push(location-10-1);
	arrayGet.push(location-10);
	arrayGet.push(location-10+1);
	arrayGet.push(location-1);
	arrayGet.push(location);
	arrayGet.push(location+1);
	arrayGet.push(location+10-1);
	arrayGet.push(location+10);
	arrayGet.push(location+10+1);
	var rtArray=[];
	for (var i = 0; i <9; i++) {// chi co 9 phan tu theo 3x3 thoi
		var num_validate=arrayGet[i];
		var cvx=num_validate%10;
		var cvy=Math.floor(num_validate/10);
		var distance=Math.sqrt(Math.pow(cvx-cx,2)+Math.pow(cvy-cy,2));
		if (num_validate>=0&&num_validate<=99&&distance<2) {
			rtArray.push(num_validate);
		}
	}
	return rtArray;
}
function logObject(obj){
	console.log("info :x=%s , y=%s, w=%s, h=%s",obj.x,obj.y,obj.w,obj.h);
}
function kiemTraVaCham(objC1,objC2){
	var dtX=Math.abs(objC1.x-objC2.x);
	var dtY=Math.abs(objC1.y-objC2.y);
	var kcW=objC1.w/2+objC2.w/2;
	var kcH=objC1.h/2+objC2.h/2;
	
	if (dtX<kcW&&dtY<kcH) {
		return true;
	}else{
		return false;
	}
}
function distace2Object(obj1,obj2){
	return Math.sqrt(Math.pow(obj1.x-obj2.x,2)+Math.pow(obj1.y-obj2.y,2));
}
function MapConvertUnit(x,y){
	var cv_x=Number(x)+1500;
	var cv_y=Number(y)+1000;
	var xp=Math.floor(cv_x/300);// map tam thoi co kich thuco la 3000,2000 
	var yp=Math.floor(cv_y/200);
	var index=Math.floor(yp*10+xp);
	if (index>99||xp>9||yp>9||index<0) {
		console.log("convert to Unit error, xp=%s yp=%s index=%s",xp,yp,index);
		return -1;
	}else{
		return index;
	}
}






function CCRoom(idroom){
	this.idNumber=""+idroom;
	this.countUser=0;
	this.PLAYLIST={};

	this.listArrOBJ=null;// Object chuong ngai vat
	this.listArrFree=null;
	this.listArrUnit=null;
}
CCRoom.prototype.getCountUser=function(){
	var numbercount=0;
	for(var user in this.PLAYLIST){
		numbercount=numbercount+1;
	}
	return numbercount;
}

CCRoom.prototype.RemovePlayerIfNeed=function(playerid){
	delete this.PLAYLIST[playerid];
}
CCRoom.prototype.AddPlayer=function(player){
	this.PLAYLIST[player.numberID]=player;

	var countFree=this.listArrFree.length;
	var rd=Math.floor(Math.random() * countFree);
	if (rd>=countFree) {
		rd=countFree-1;
	}
	
	var objFree=this.listArrFree[rd];
	logObject(objFree);
	 // playerid.pos.x=Number(objFree.x);
	 // playerid.pos.y=Number(objFree.y);
	console.log("rd: %s vi tri x=%s y=%s",rd,objFree.x,objFree.y);
}
CCRoom.prototype.loadMapAndAI=function(){
	fs = require('fs')
	var fs = require('fs');
	var obj = JSON.parse(fs.readFileSync('./Map/mapgame1.json', 'utf8'));
	this.listArrOBJ=obj.mapObstacle;
	this.listArrFree=obj.mapFreeRect;
	this.listArrUnit=obj.Unit;
	console.log("MAP %s IS LOADED",this.idNumber);
/* 	//chi danh cho test map ma thoi
	var m_free=this.listArrFree.length;
	for (var kf = 0; kf < m_free; kf++) {
		var tmp_free=this.listArrFree[kf];
		var arr_Ob_arroundme=this.getAllObstacbesAroundMe(tmp_free.x,tmp_free.y);
		var tmp_length_arround=arr_Ob_arroundme.length;
		for (var iar = 0; iar < tmp_length_arround; iar++) {
			var tmp_obs=arr_Ob_arroundme[iar];
			if (kiemTraVaCham(tmp_free,tmp_obs)) {
				logObject(tmp_obs);
				console.log("co va cham roi: %s / %s",tmp_free.id,kf);
			}
		}
	}
*/


}
CCRoom.prototype.updateFrameStep=function(dttime){
	
	for(var i  in this.PLAYLIST){
		var pack_info_tank=[];
		var pack_info_obstacble=[];
		var player_tmp=this.PLAYLIST[i];
		
		player_tmp.updatePosition(dttime);
		player_tmp.updateGunRotationAndFire(dttime);

		pack_info_tank.push({
			x:player_tmp.pos.x.toFixed(2)+"",
			y:player_tmp.pos.y.toFixed(2)+"",
			id:player_tmp.numberID+"",
			r:player_tmp.r.toFixed(2)+"",
			//typeTank:player_tmp.typeTank,
			lbdisplay:player_tmp.lbdisplay,
			level:player_tmp.level+"",
			score:player_tmp.score+"",
			gR:player_tmp.gunRotation+""
		}
		);
		

		//pack_info_tank.push('10,20,15,45,20,11,22');

		var arr_Obs_arround=this.getAllObstacbesAroundMe(player_tmp.pos.x,player_tmp.pos.y);
		var max_allObject=arr_Obs_arround.length;
		
		for (var idobj = 0; idobj < max_allObject; idobj++) {
			var tmpObs=arr_Obs_arround[idobj];
			var distance=distace2Object(tmpObs,player_tmp.pos);
			if (distance<400) {
				pack_info_obstacble.push({
				x:tmpObs.x,
				y:tmpObs.y,
				w:tmpObs.w,
				h:tmpObs.h,
				id:tmpObs.id
			});
			}
			
		}

		//console.log("max_allObject: %s, %s",max_allObject,pack_info_tank.length);
		
		player_tmp.pack_player=pack_info_tank;
		player_tmp.pack_obs=pack_info_obstacble;
	}

	
}

CCRoom.prototype.getAllObstacbesAroundMe=function(x,y){
	var p2unit=MapConvertUnit(x,y);// convert thanh vi tri don vi 0-99
	var arrIndexArrount=getMapAround(p2unit);//lay ra cac don vi xung quanh no
	var maxIAr=arrIndexArrount.length;
	var AllObjectRT=[];
	for (var ir = 0; ir < maxIAr; ir++) {
		var indexOfU=arrIndexArrount[ir];// lay ra thu tu cua array unit
		var groupUnit=this.listArrUnit[indexOfU];// lay ra tu group va add no vao allObject
		var maxLUnit=groupUnit.length;
		for (var iu = 0; iu < maxLUnit; iu++) {
			AllObjectRT.push(groupUnit[iu]);
		}
	}
	return AllObjectRT;
}

module.exports=CCRoom;