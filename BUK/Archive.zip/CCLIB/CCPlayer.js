
var CCVector=require('./CCVector');

function CCPlayer(id){
	this.numberID=""+id;
	this.pos=new CCVector(0,0);
	this.r=0;
	this.name="USR:"+id;
	this.typeTank=1;
	this.MVSTT=0;
	this.isRemove=false;
	this.mySpeed=0.8;
}
CCPlayer.prototype.updatePosition=function(){
	if (this.MVSTT==1) 
			{
				this.pos.x+=this.mySpeed;
				this.r=0;
				if (this.x>550) {
					this.x=-550;
				}
			}
		else if (this.MVSTT==2) 
			{
				this.pos.y-=this.mySpeed;
				this.r=90;
				if (this.y<-280) {
					this.y=280;
				}
			}
		else if (this.MVSTT==3) 
			{
				this.pos.x-=this.mySpeed;
				this.r=180;
				if (this.x<-550) {
					this.x=550;
				}
			}
		else if (this.MVSTT==4) 
			{
				this.pos.y+=this.mySpeed;
				this.r=-90;
				if (this.y>280) {
					this.y=-280;
				}
			}
}


module.exports=CCPlayer;