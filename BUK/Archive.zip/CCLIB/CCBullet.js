var CCVector=require('./CCVector');

function CCBullet(id_player,id_bullet){
	this.numberID=""+id_bullet;
	this.idplayer=id_player;
	this.pos=null;
	this.starPos=null; 
	this.r=0;
	this.moveVector=null;
	this.isRemove=false;
	this.mySpeed=400;//velocity
}
CCBullet.prototype.updatePosition=function(delta_time){
	
	var length=this.pos.getDistance(this.starPos);
	if (length>450) {
		this.isRemove=true;
	}else{
		var vt_unit=new CCVector(this.moveVector.ux,this.moveVector.uy);//lay ra vector don vi cua no
		vt_unit.multipleNumber(delta_time*this.mySpeed);// nhan voi quang duong di duoc( quang duong thi baang speed*delta_time)
		// cong voi vector nhan
		this.pos.addVector(vt_unit);
	}
}


module.exports=CCBullet;