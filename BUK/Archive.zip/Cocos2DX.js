var CCPlayer=require('./CCLIB/CCPlayer');
var CCVector=require('./CCLIB/CCVector');
var CCBullet=require('./CCLIB/CCBullet');

var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
app.use(express.static(__dirname + '/DataGame'));

http.listen(2000, function(){
	console.log('listening on : 2000');
});



console.log("Server bat dau khoi chay----->");



var count_Bullet=1;// id cua vien dan tang dan, neu lon hon 100000 chang han thi reset ve =0
var count_TypePlay=1;
var count_Connect=1;

var USR_LIST={};
var PLAYER_LIST={};
var BULLET_LIST={};


io.on('connection', function(socket_client){
	if (count_TypePlay>5) {
		count_TypePlay=1;
	}else if (count_TypePlay<1) {
		count_TypePlay=5;
	}

	count_Connect=count_Connect+1;
	if (count_Connect>100000) {
		count_Connect=0;
	}
	socket_client.numberID=""+count_Connect;
	USR_LIST[socket_client.numberID]=socket_client;

	var player_tmp=new CCPlayer(socket_client.numberID);
	PLAYER_LIST[socket_client.numberID]=player_tmp;
	player_tmp.typeTank=""+count_TypePlay;

	

	socket_client.emit('LoadUserInfo', socket_client.numberID);
	count_TypePlay=count_TypePlay+1;


	socket_client.on('changeDir',function(data_client){
		player_tmp.MVSTT=data_client;
	});

	socket_client.on('fireTarget',function(vector_mv){
		var vt_fire=JSON.parse(vector_mv);;
		var bullet_temp=new CCBullet(socket_client.numberID,count_Bullet);
		count_Bullet+=1;
		bullet_temp.pos=new CCVector(player_tmp.pos.x,player_tmp.pos.y);
		bullet_temp.starPos=new CCVector(player_tmp.pos.x,player_tmp.pos.y);
		bullet_temp.moveVector=new CCVector(vt_fire.x,vt_fire.y);
		console.log("bullet_temp.pos: X:"+vector_mv +" x :"+bullet_temp.pos.x+" y:"+bullet_temp.pos.y);
		BULLET_LIST[bullet_temp.numberID]=bullet_temp;
	});

	socket_client.on('disconnect',function(){
		var player_out=PLAYER_LIST[socket_client.numberID];
		player_out.isRemove=true;// ko hieu sao khong xoa duoc nen dat status nay o day
		delete USR_LIST[socket_client.numberID];
		delete PLAYER_LIST[socket_client.numberID];
		console.log('user  '+socket_client.numberID+' has logout ');
	});
});


var time_step=1000/50;
setInterval(function(){
	var pack_info_tank=[];
	for(var i  in PLAYER_LIST){
		var player_tmp=PLAYER_LIST[i];
		if (player_tmp.isRemove) {
			continue;
		}
		player_tmp.updatePosition();
		pack_info_tank.push({
			x:player_tmp.pos.x,
			y:player_tmp.pos.y,
			id:player_tmp.numberID,
			r:player_tmp.r,
			typeTank:player_tmp.typeTank
		}
		);
	}

	var pack_info_bullet=[];
	for(var i  in BULLET_LIST){
		var bl=BULLET_LIST[i];
		if (bl.isRemove){
			delete BULLET_LIST[i];// delete trong vong for se bi loi, co the la bi loi cho nay :(
			continue;
		}
		bl.updatePosition(time_step/1000);
		pack_info_bullet.push({
			x:bl.pos.x,
			y:bl.pos.y,
			id:bl.numberID
		});
	}

	


	for(var i  in USR_LIST){
		var usr_tmp=USR_LIST[i];
		usr_tmp.emit('UpdatePosition',{tank:pack_info_tank,bullet:pack_info_bullet});
	}






},time_step);
















